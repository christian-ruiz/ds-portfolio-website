# ds-portfolio-website

React + Vite + Tailwind portfolio for Christian Ruiz.

## Development
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
```

## Deployment
Push to `main` and GitHub Actions will deploy to Pages automatically at:
https://christian-ruiz.github.io/ds-portfolio-website/
